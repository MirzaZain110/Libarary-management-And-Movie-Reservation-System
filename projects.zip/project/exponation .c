#include<stdio.h>
int main()
{
	int num1,num2;
	printf("Enter to number : ");
	scanf("%d  ",&num1);
	printf("enter sceond number");
	scanf("%d ",&num2);
    if(num1==num2)
    printf("equal ");
     else if(num1<num2)
    printf("grwater");
     else if(num1>num2)
    printf("less");
    else if(num1<=num2)
    printf("greater equal");
    else
    printf("less equal");
    
     
}
