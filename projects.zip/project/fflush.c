#include<stdio.h>
int main()
{
	char ch ;
	int i;
	printf("Enter the integer ");
	scanf("%d",&i);
	getchar();
	printf("enter the charater ");
	scanf("%c",&ch);
	printf("The %d and character %c",i,ch);
}
