#include<stdio.h>
int main()
{
	int a,b,c=1;
	printf("Enter the value of n! : ");
	scanf("%d",&b);
	for(a=1;a<=b;a++)
	{
		printf("\n%d",a);
		c=c*a;
	}
	printf("\nThe value is %d",c);
}
