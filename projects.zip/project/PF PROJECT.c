#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<windows.h>
#include<conio.h>
char movie1name[30];
char movie2name[30];
char movie3name[30];
char movie4name[30];


void title(void);
void admin(void);
void allrecords(void);
void Dlt_rec(void);
void Dlt_all_rec(void);
void displaymovietobeaired(void);
void addingcustomers(void);
void pswrd_change(void);
void edit_record(void);
void editmovies(void);
void Search_rec(void);


    int b,valid=0;
    int ok;
    int movie1price=400;
    int movie2price=450;
    int movie3price=620;
    int movie4price=500;



struct customer
{
     int age;
	 char Gender;
	 char First_Name[20];
	 char Last_Name[20];
	 char Contact_no[15];
	 char Address[30];
	 char movieselection[15];
	 int seatnumber;
     int expenses;
     int additionalexp;
     int totalexp;

};
struct customer  p,temp_c;


/*************************************************************************************************end**************************************************************************************/






    void menuchoices()
 {
    printf("\t\t\t\t  Welcome ! Please select an option from below .\n\n");
    printf("\t\t\t\t   Enter the number of that respective option\n\n");
    printf("\t\t\t\t  1). View movies to be aired. \n\n");
    printf("\t\t\t\t  2). Access admin panel (Requires password). \n\n");
    printf("\t\t\t\t  3). Book a ticket for the customer.\n\n");
    printf("\t\t\t\t  4). Exit  \n\n");
 }








/*************************************************************************************************MAIN**************************************************************************************/

int main()
{

    A:
    system("cls");
    title();
    menuchoices();
    int menuopt;
    char menu;
    while(1)
    {
          scanf("%d",&menuopt);
          switch(menuopt)
       {

        case 1:
         {
		    displaymovietobeaired();
            printf("\n\nPress any key to return");
            getch();
            main();
            break;
		  }
        case 2:
         {
		    admin();
            break;
		 }

        case 3:
         {
			addingcustomers();
            break;
		 }
        case 4:
         {
			ExitProcess(1);
            break;
	     }
       }
    }
}
/*************************************************************************************************Prints title on every screen*******************************************************************************/
void title()
{
    system("color b0");
    printf("\t\t\t\t  ===============================================\n");
    printf("\t\t\t\t    ===========================================\n");
    printf("\n\n\t\t\t\t     Movie booking system developed by FAST\n\n\n");
    printf("\t\t\t\t    ===========================================\n");
    printf("\t\t\t\t  ==============================================\n\n");
}
/*************************************************************************************************End of title ************************************************************************************************/


/*************************************************************************************************Deletes all the record in the storage **********************************************************************************/
void Dlt_all_rec()
{
    remove("CusRecord.dat");
    printf("\n\t\tAll records deleted successfully");
    getch();
    main();

}
/*************************************************************************************************End of Dlt_all_rec function**********************************************************************************************/


/*************************************************************************************************Display movie to be aired***********************************************************************************************/
void displaymovietobeaired()
{

        system("cls");
        title();
        FILE *fptr,*fptr2,*fptr3,*fptr4;
        fptr=fopen("movie1.txt","r");
        fptr2=fopen("movie2.txt","r");
        fptr3=fopen("movie3.txt","r");
        fptr4=fopen("movie4.txt","r");
        printf("\n\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        fscanf(fptr, "%s", movie1name);
        printf("\n\n\t\t\t\t\tSlot -1 %s will be aired at 5:00 Pm (%d) RS",movie1name,movie1price);
        fclose(fptr);
        fscanf(fptr2, "%s", movie2name);
        printf("\n\n\t\t\t\t\tSlot -2 %s will be aired at 8:00 Pm (%d) RS",movie2name,movie2price);
        fclose(fptr2);
        fscanf(fptr3, "%s", movie3name);
        printf("\n\n\t\t\t\t\tSlot -3 %s will be aired at 10:00 Pm (%d) RS",movie3name,movie3price);
        fclose(fptr3);
        fscanf(fptr4, "%s", movie4name);
        printf("\n\n\t\t\t\t\tSlot -4 %s will be aired at 11:00 Pm (%d) RS",movie4name,movie4price);
        fclose(fptr4);
        printf("\n\n\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

}
/************************************************************************************************  End of Displayall_movies function  ************************************************************************************************/



/************************************************************************************************  Display all the records stored   ***************************************************************************************************/
void allrecords()
{


    	system("cls");
    	title();
    	FILE *ptr;
	    ptr=fopen("CusRecord.dat","r");
    
		printf("\n\n\t\t\t\t\t+++++LIST OF ALL THE RECORDS+++++\n");

		printf("Full Name\t");

		printf("Gender\t");

		printf("Age\t");

		printf("Address\t");

		printf("Contact No\t");

		printf("Seat Number\t");

		printf("Movie And Expenses");

		printf("\n===============================================================================================================\n");

		while(fscanf(ptr,"%s %s %c %d %s %s %d %s %d/n",p.First_Name,p.Last_Name, &p.Gender, &p.age, p.Address, p.Contact_no,&p.seatnumber,&p.movieselection,&p.totalexp)!=EOF)
		
		{

   	        printf("\n");
		
 			printf("%s %s\t",p.First_Name, p.Last_Name);

 			printf("%c\t",p.Gender);

 	        printf("%d\t",p.age);

 			printf("%s\t",p.Address);
 
  			printf("%s\t",p.Contact_no);
 
       		printf("%d\t\t",p.seatnumber);

 			printf(" %s  %d RS",p.movieselection,p.totalexp);

		}
	     fclose(ptr);
	     getch();
	     main();
}
/************************************************************************************************  End of Display all the records function   ***************************************************************************************************/



/************************************************************************************************  Display all the all the options for admin function   *****************************************************************************************/
void menuforadmin()
{


     printf("\n\t\t\t\t1). Add movie to be aired");
     printf("\n\n\t\t\t\t2). Change password for admin panel.");
     printf("\n\n\t\t\t\t3). View all reservations.");
     printf("\n\n\t\t\t\t4). Delete a reservation ");
     printf("\n\n\t\t\t\t5). Delete all the records ");
     printf("\n\n\t\t\t\t6). Search a record ");
     printf("\n\n\t\t\t\t7). Press 0 to return !");

}

/************************************************************************************************  End of Admin options function   ***************************************************************************************************/



     char password[15];
     char str[15];

/************************************************************************************************* Admin Panel function  ****************************************************************************************************************************/

void admin()
{
     fflush(stdin);
     system("cls");
     title();
     int outercount=0;
     FILE *fp;
     printf("\n\t\t\tEnter admin password to access  ");
     A1:
     gets(password);
     fp = fopen("password.txt","r");
     fscanf(fp,"%s",str);


         if(strcmp(str,password)==0)     //This block check whether the password is correct and returns main if tries exceed three times
       {
            printf("\n\t\t\t\tPassword is correct  ");
       }
        else
            {
			  if(outercount<3)
                {   printf("\n\t\t\t\tPassword is wrong . Enter Again !");
                    outercount++;
                    goto A1;
				}
                else
                {
				printf("\n\n\t\t\tPassword limit reached ! Press any key to return to main menu !");
                getch();
                main();
				}
            
			}

    int opt;

    system("cls");
    title();
    menuforadmin();  // printf options for admin sub menu
    
	     while(1)
       {
         scanf("%d",&opt);
    
	switch(opt)
    {
    case 0:
           main();
          break;
    case 1:
          editmovies();
         break;
    case 2:
        pswrd_change();
        break;
    case 3:
        allrecords();
        break;
    case 4:
        Dlt_rec();
        break;
    case 5:
        Dlt_all_rec();
        break;
    case 6:
        Search_rec();

    }

        }
}

/*************************************************************************************************end of admin function**************************************************************************************/




/************************************************************************************************* Changing password **************************************************************************************/

void pswrd_change()
{
    FILE *fp;
    fp = fopen("password.txt","r");
    system("cls");
    FILE *newpswrd;
    int count=0;
	printf("Enter the old password ! ");
    A3:
    fflush(stdin);
    gets(password);
    fp = fopen("password.txt","r+");

    while (fgets(str,15, fp) != NULL)
           fclose(fp);
    if(strcmp(str,password)==0)
       {
         printf("\nPassword is correct  ");
        }
         else
        {
		    if(count<3)
            
			{
			printf("\n\nPassword is wrong . Enter Again !");
            count++;
            goto A3;
			}
            
			else
            printf("Password limit reached ! Press any key to return to main menu !");
            getch();
        
		    main();
        }
    fflush(stdin);
    char newpassword[15];
    printf("\nEnter the new password for admin panel !  ");
    scanf("%s",&newpassword);
    fputs(newpassword,fp);
    fclose(fp);
    printf("\n\nPassword for admin panel has been changed succesfully");
    getch();
    main();
}
/*************************************************************************************************End of password change function*************************************************************************/


/*************************************************************************************************Deletes a user record**************************************************************************************/
void Dlt_rec()
{
	char name[20];
	char moviename[20];
	int found=0;
	system("cls");
    title();// call Title function
	FILE *ptr, *ft;
	ft=fopen("temp_file2.dat","w+");
	ptr=fopen("CusRecord.dat","r");
	
	printf("\n\n\t\t\t!!!!!!!!!!!!!! Delete Patients Record !!!!!!!!!!!!!\n\n\n");

	printf("\n\t\tEnter First name to delete the record : ");
	
	fflush(stdin);
	gets(name);
	
	printf("\n\t\tEnter Movie name to delete the record : ");
	
	displaymovietobeaired();
	gets(moviename);

	while(fscanf(ptr,"%s %s %c %i %s %s %d %s %d", p.First_Name, p.Last_Name, &p.Gender, &p.age, p.Address, p.Contact_no,&p.seatnumber,&p.movieselection,&p.expenses)!=EOF)
	{
		if (strcmp(p.First_Name,name)!=0 || strcmp(p.movieselection,moviename)!=0)
		
	  	     fprintf(ft," %s %s %c %i %s %s %d %s %d", p.First_Name, p.Last_Name, p.Gender, p.age, p.Address, p.Contact_no,p.seatnumber,p.movieselection,p.expenses);

		else if((strcmp(p.First_Name,name)==0 && strcmp(p.movieselection,moviename)==0))
		{
			 printf(" \n\n%s %s %c %i %s %s %d %s %d", p.First_Name, p.Last_Name, p.Gender, p.age, p.Address, p.Contact_no,p.seatnumber,p.movieselection,p.expenses);
			 found=1;
		}
	}//while loop ends
	if(found==0)
	{
		 printf("\n\n\t\t\t Record not found....");
		 getch();
		 main();
	}
	else
	{
		 fclose(ptr);
		 fclose(ft);
		 remove("CusRecord.dat");
		 rename("temp_file2.dat","CusRecord.dat");
		 printf("\n\n\t\t\t Record deleted successfully :) ");
		 getch();
		 main();
	}
}
/*************************************************************************************************End of Dlt_rec function ************************************************************************************************/






/*************************************************************************************************adding reservation**************************************************************************************/



void addingcustomers()
{

    system("cls");
	title();// call Title function
	//list of variables
	int loop;
	int tempseat;
	int counterforexit=0;
	char input;
	FILE*ptr;//file pointer
	ptr=fopen("CusRecord.dat","a");//open file in write mode
	printf("\n\n\t\t\t!!!!!!!!!!!!!! Add customer Record !!!!!!!!!!!!!\n");
	
	W:
	displaymovietobeaired();
	printf("\n");
	fflush(stdin);
	printf("\t\tType movie name for the booking ! or type 'exit' to go  back ");
	scanf("%s",&p.movieselection);
    if(strcmp(p.movieselection,movie1name)==0 )
    {
         p.expenses=movie1price;
         M:
         printf("\n\t\t\tSeat  no: ");
         scanf("%d",&tempseat);

        if(tempseat>30 || tempseat<0)
            {
		   	 printf("\n\t\t\tEnter a valid seat number between 1-30");
             goto M;
			}
        else
            while(fscanf(ptr,"%s %d",&p.movieselection,&p.seatnumber)!=EOF)
            {
                 if(tempseat==p.seatnumber  && (strcmp(p.movieselection,movie1name)==0))
                {
                     printf("\n\t\t\tSeat already booked");
                     goto M;
                }
                else
                     goto A;
            }

    }
    else if(strcmp(p.movieselection,movie2name)==0 )
    {
         p.expenses=movie2price;
         R:
         fflush(stdin);
         printf("\n\t\t\tSeat  no: ");
         scanf("%d",&tempseat);

        if(tempseat>30 || tempseat<0)
            {
			 printf("\n\t\t\tEnter a valid seat number between 1-30");
             goto R;
			}
         else
             while(fscanf(ptr,"%s %d",p.movieselection,&p.seatnumber)!=EOF)
             {
                 if(tempseat==p.seatnumber && (strcmp(movie2name,p.movieselection)==0))
                 {
                     printf("\n\t\tSeat already booked");
                     goto R;
                 }
                else
                     goto A;
             }

    }
    else if(strcmp(p.movieselection,movie3name)==0 )
    {
         p.expenses=movie3price;
         Q:
         fflush(stdin);
         printf("\n\t\t\tSeat  no: ");
         scanf("%d",&tempseat);

        if(tempseat>30 || tempseat<0)
            {
			 printf("\n\t\t\tEnter a valid seat number between 1-30");
             goto Q;}
        else

            while(fscanf(ptr,"%s %d",&p.movieselection,&p.seatnumber)!=EOF)
            {
                 if(tempseat==p.seatnumber && (strcmp(movie3name,p.movieselection)==0))
                 {
                     printf("\n\t\tSeat already booked");
                     goto Q;
                 }
                 else
                     goto A;
            }

    }
    else if(strcmp(p.movieselection,movie4name)==0 )
    {
         p.expenses=movie4price;
         N:
         fflush(stdin);
         printf("\n\t\t\tSeat  no: ");
         scanf("%d",&tempseat);

         if(tempseat>30 || tempseat<0)
            { 
			     printf("\n\t\t\tEnter a valid seat number between 1-30");
                 goto N;
			}
         else
            while(fscanf(ptr,"%s  %d",&p.movieselection,&p.seatnumber)!=EOF)
            {
                if(tempseat==p.seatnumber && (strcmp(movie4name,p.movieselection)==0))
                {
                    printf("\n\t\tSeat already booked");
                    goto N;
                }
                else
                    goto A;;
            }

    }
    else if(strcmp(p.movieselection,"exit")==0)
    {
     printf("\t\t\t Press any key to return to main menu");
     getch();
     main();

     }   
    else
    {
	     if(counterforexit<3)
       {
             printf("\t\t\tINVALID INPUT ! TRY AGAIN ");
             getch();
             counterforexit++;
             goto  W;
       }
         else
       {
             printf("Press any key to return to main menu");
             getch();
             main();
       }
    }

	 A:
     p.seatnumber=tempseat;
     printf("\n\t\t\tFirst Name: ");
 	 scanf("%s",p.First_Name);
	 if(strlen(p.First_Name)>20||strlen(p.First_Name)<2)
	 {
	 	 printf("\n\t Invalid :( \t The max range for first name is 20 and min range is 2 :)");
	   	 goto A;
	 } 
	 else
	 {
	  	 for (b=0;b<strlen(p.First_Name);b++)
		 {
			 if (isalpha(p.First_Name[b]))
			   {
				 valid=1;
			   }
			 else
			   {
			 	 valid=0;
				 break;
		       }
		 }
	 if(valid==0)
		{
			printf("\n\t\t First name contain Invalid character :(  Enter again :)");
			goto A;
		}
	 }
	/* ********************************************** Last name ************************************************ */
	 B:
     fflush(stdin);
	 printf("\n\t\t\tLast Name: ");
     scanf("%s",p.Last_Name);
     if(strlen(p.Last_Name)>20||strlen(p.Last_Name)<2)
	 {
	  	 printf("\n\t Invalid :( \t The max range for last name is 20 and min range is 2 :)");
		 goto B;
	 }
	 else
	 {
		 for (b=0;b<strlen(p.Last_Name);b++)
		 {
		  	 if (isalpha(p.Last_Name[b]))
			   {
			 	 valid=1;
			   }
			 else
			 {
				 valid=0;
				 break;
			 }
		 }
	         if(valid==0)
		       {
	 	         printf("\n\t\t Last name contain Invalid character :(  Enter again :)");
		         goto B;
		       }
	         else
                 goto E;
	}
	/* ******************************************* Gender ************************************************************** */
	do
	{
	     E:
	     printf("\n\t\t\tGender[F/M]: ");
		 scanf(" %c",&p.Gender);
		if(p.Gender=='M'|| p.Gender=='F' ||  p.Gender=='m'|| p.Gender=='f')
		   {
		 	 ok =1;
		   }
		else
		   {
		 	 ok =0;
		   }
        if(ok==0)
	       {
	    	 printf("\n\t\t Gender contain Invalid character :(  Enter either F or M :)");
    	   }  
	}while(ok==0);
	/* ***************************************** Age ********************************************************************** */
    
	 printf("\n\t\t\tAge:");
     scanf(" %d",&p.age);
    /* **************************************** Address ******************************************************************* */
	    C:
	    printf("\n\t\t\tAddress: ");
	    scanf("%s",p.Address);
	    if(strlen(p.Address)>20||strlen(p.Address)<4)
		{
			printf("\n\t Invalid :( \t The max range for address is 20 and min range is 4 :)");
			goto C;
		}
		else
            goto D;

	/* ******************************************* Contact no. ***************************************** */
	do
	{
		D:
	    printf("\n\t\t\tContact no: ");
	    scanf("%s",&p.Contact_no);
	    if(strlen(p.Contact_no)!=11)
		{
			printf("\n\t Sorry :( Invalid. Contact no. must contain 11 numbers. Enter again :)");
			goto D;
		}
		else
		{
			for (b=0;b<strlen(p.Contact_no);b++)
			{
				if (isdigit(p.Contact_no[b]))
				{
					valid=1;
				}
				else
				{
					valid=0;
					break;
				}
			}
			if(valid==0)
			{
				printf("\n\t\t Contact no. contain Invalid character :(  Enter again :)");
				goto D;
			}
		}
	}while(valid==0);

	 printf("\n\t\t\tAdditional expenses in PKR: ");
     scanf("%d",&p.additionalexp);
     p.totalexp=p.additionalexp+p.expenses;
     fprintf(ptr," %s %s %c %d %s %s %d %s %d", p.First_Name, p.Last_Name, p.Gender, p.age, p.Address, p.Contact_no,p.seatnumber,p.movieselection,p.totalexp);
     printf("\n\n\t\t\t.... Information Record Successful ...");
     fclose(ptr);//ptr file is closed
     fflush(stdin);
     printf("\n\n\t\t\tDo you want to add more[Y] / [Any key to end] ? ?? ");
     scanf("%c",&input);
     if (input=='y' || input=='Y')
	   {
     	  addingcustomers();
	   }
     else
	   {
		 printf("\n\t\t Thank you :) :)");
    	 getch();
    	 main();
	   }
}
/*************************************************************************************************end of adding reservation**************************************************************************************/


/************************************************************************************************* Edit names of movies to be aired **************************************************************************************/
void editmovies()
{
        int slot;
        system("cls");
        displaymovietobeaired();
        printf("\nEnter the new movie to be aired along with its timing .");
        printf("\nThere can be only 4 slots for movies at a time .");
        printf("\nEnter the slot number !s .");
        scanf("\n%d",&slot);
        switch(slot)

        {

             case 1:
               {
                 FILE *movie1;
                 movie1=fopen("movie1.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",5);
                 gets(movie1name);
                 fputs(movie1name,movie1);
                 fclose(movie1);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
                 break;
                }
             case 2:
                { 
                 FILE *movie2;
                 movie2=fopen("movie2.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",8);
                 gets(movie2name);
                 fputs(movie2name,movie2);
                 fclose(movie2);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
                 break;
                }
                 case 3:
               {
                 FILE *movie3;
                 movie3=fopen("movie3.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",10);
               	 gets(movie3name);
                 fputs(movie3name,movie3);
                 fclose(movie3);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
			  	 break;
                }
                 case 4:
               {
                 FILE *movie4;
                 movie4=fopen("movie4.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",11);
                 gets(movie4name);
                 fputs(movie4name,movie4);
                 fclose(movie4);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
                 break;
                }
        }
}
/*************************************************************************************************end of  edit movies function **************************************************************************************/


/************************************************************************************************* Edit names of movies to be aired **************************************************************************************/
void Search_rec()
{

    char firstname[20];
	system("cls");
	title();// call Title function
	FILE *ptr;
	ptr=fopen("CusRecord.dat","r");
	printf("\n\n\t\t\t!!!!!!!!!!!!!! Search customer Record !!!!!!!!!!!!!\n\n");
	printf("\n Enter the first name of the customer :");
	scanf("%s",firstname);
	valid=0;
	fflush(stdin);
	printf("\t\t<-------Below are all the record found with this first name ------->");
	if(ptr==NULL)
    {
        printf("\n\n\t\t\tNo record found");
    }
    else
	{
	    while(fscanf(ptr,"%s %s %c %d %s %s %d %s %d/n",p.First_Name,p.Last_Name, &p.Gender, &p.age, p.Address, p.Contact_no,&p.seatnumber,&p.movieselection,&p.expenses)!=EOF)
		{
		    if(strcmp(p.First_Name,firstname)==0)

            {
		 	 printf("\n");
			 printf("%s %s\t",p.First_Name, p.Last_Name);
		     printf("%c\t",p.Gender);
	         printf("%d\t",p.age);
			 printf("%s\t",p.Address);
			 printf("%s\t",p.Contact_no);
             printf("%d\t\t",p.seatnumber);
			 printf(" %s  %d RS",p.movieselection,p.expenses);
			 valid=1;
			}

		}
    if(valid==0)
    {
        printf("\n\t\t\tNo record found !");
    }
	
	}
	 fclose(ptr);
	 getch();
	 main();
}

