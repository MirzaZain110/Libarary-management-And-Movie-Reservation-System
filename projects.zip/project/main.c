#include <stdio.h>

#include <stdlib.h>

#include<string.h>

#include<conio.h>

char movie1name[30];
char movie2name[30];
char movie3name[30];
char movie4name[30];

void title(void);
void admin(void);
void allrecords(void);
void delete_rec(void);
void Dlt_all_rec(void);
void displaymovietobeaired(void);
void addingcustomers(void);
void pswrd_change(void);
void edit_record(void);
void editmovies(void);
void Search_rec(void);
void menuchoices(void);

int b, control = 0;
int temp;

int movie1price = 400;
int movie2price = 450;
int movie3price = 620;
int movie4price = 500;

struct customer {
        int age;
        char Gender;
        char First_Name[20];
        char Last_Name[20];
        char Contact_no[15];
        char Address[30];
        char movieselection[15];
        int seatnumber;
        int expenses;
        int additionalexp;
        int totalexp;

};
struct customer rec, temp_c;

/*************************************************************************************************end**************************************************************************************/

/*************************************************************************************************MAIN**************************************************************************************/

int main() {

        A: system("cls");
        title();
        menuchoices();
        int menuopt;
        char menu;
        while (1) {
                scanf("%d", & menuopt);
                switch (menuopt) {

                case 1: {
                        displaymovietobeaired();
                        printf("\n\nPress any key to return");
                        getch();
                        main();
                        break;
                }
                case 2: {
                        admin();
                        break;
                }

                case 3: {
                        addingcustomers();
                        break;
                }
                case 4: {
                        ExitProcess(1);
                        break;
                }
                }
        }
}
/*************************************************************************************************Prints title on every screen*******************************************************************************/
void title() {
        system("color b0");
        printf("\t\t\t\t  ===============================================\n");
        printf("\t\t\t\t    ===========================================\n");
        printf("\n\n\t\t\t\t     Movie booking system developed by FAST\n\n\n");
        printf("\t\t\t\t    ===========================================\n");
        printf("\t\t\t\t  ==============================================\n\n");
}
/*************************************************************************************************End of title ************************************************************************************************/

/************************************************************************************************* Mian menu choices **************************************************************************************/

void menuchoices() {
        printf("\t\t\t\t  Welcome ! Please select an option from below .\n\n");
        printf("\t\t\t\t   Enter the number of that respective option\n\n");
        printf("\t\t\t\t  1). View movies to be aired. \n\n");
        printf("\t\t\t\t  2). Access admin panel (Requires password). \n\n");
        printf("\t\t\t\t  3). Book a ticket for the customer.\n\n");
        printf("\t\t\t\t  4). Exit  \n\n");
}

/*************************************************************************************************end**************************************************************************************/

/************************************************************************************************  Display all the all the options for admin function   *****************************************************************************************/
void menuforadmin() {

        printf("\n\t\t\t\t1). Add movie to be aired");
        printf("\n\n\t\t\t\t2). Change password for admin panel.");
        printf("\n\n\t\t\t\t3). View all reservations.");
        printf("\n\n\t\t\t\t4). Delete a reservation ");
        printf("\n\n\t\t\t\t5). Delete all the records ");
        printf("\n\n\t\t\t\t6). Search a record ");
        printf("\n\n\t\t\t\t7). Edit personal information of a record ");
        printf("\n\n\t\t\t\t8). Press 0 to return !");

}

/************************************************************************************************  End of Admin options function   ***************************************************************************************************/

/*************************************************************************************************Deletes all the record in the storage **********************************************************************************/
void Dlt_all_rec() {
        remove("CusRecord.dat");
        remove("temp.dat");
        printf("\n\t\tAll records deleted successfully");
        getch();
        main();

}
/*************************************************************************************************End of Dlt_all_rec function**********************************************************************************************/

/*************************************************************************************************Display movie to be aired***********************************************************************************************/
void displaymovietobeaired() {

        system("cls");
        title();
        FILE * fptr, * fptr2, * fptr3, * fptr4;
        fptr = fopen("movie1.txt", "r");
        fptr2 = fopen("movie2.txt", "r");
        fptr3 = fopen("movie3.txt", "r");
        fptr4 = fopen("movie4.txt", "r");
        printf("\n\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        fscanf(fptr, "%s", movie1name);
        printf("\n\n\t\t\t\t\tSlot -1 %s will be aired at 5:00 Pm (%d) RS", movie1name, movie1price);
        fclose(fptr);
        fscanf(fptr2, "%s", movie2name);
        printf("\n\n\t\t\t\t\tSlot -2 %s will be aired at 8:00 Pm (%d) RS", movie2name, movie2price);
        fclose(fptr2);
        fscanf(fptr3, "%s", movie3name);
        printf("\n\n\t\t\t\t\tSlot -3 %s will be aired at 10:00 Pm (%d) RS", movie3name, movie3price);
        fclose(fptr3);
        fscanf(fptr4, "%s", movie4name);
        printf("\n\n\t\t\t\t\tSlot -4 %s will be aired at 11:00 Pm (%d) RS", movie4name, movie4price);
        fclose(fptr4);
        printf("\n\n\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

}
/************************************************************************************************  End of Displayall_movies function  ************************************************************************************************/

/************************************************************************************************  Display all the records stored   ***************************************************************************************************/
void allrecords() {

        system("cls");
        title();
        FILE * ptr;
        ptr = fopen("CusRecord.dat", "r");
        printf("\n\n\t\t\t\t\t+++++LIST OF ALL THE RECORDS+++++\n");

        printf("Full Name\t");

        printf("Gender\t");

        printf("Age\t");

        printf("Address\t");

        printf("Contact No\t");

        printf("Seat Number\t");

        printf("Movie And Expenses");

        printf("\n===============================================================================================================\n");

        while (fscanf(ptr, "%s %s %c %d %s %s %d %s %d/n", rec.First_Name, rec.Last_Name, & rec.Gender, & rec.age, rec.Address, rec.Contact_no, & rec.seatnumber, & rec.movieselection, & rec.totalexp) != EOF) {

                printf("\n");
                printf("%s %s\t", rec.First_Name, rec.Last_Name);

                printf("%c\t", rec.Gender);

                printf("%d\t", rec.age);

                printf("%s\t", rec.Address);

                printf("%s\t", rec.Contact_no);

                printf("%d\t\t", rec.seatnumber);

                printf(" %s  %d RS", rec.movieselection, rec.totalexp);

        }
        fclose(ptr);
        getch();
        main();
}
/************************************************************************************************  End of Display all the records function   ***************************************************************************************************/

char password[15];
char str[15];

/************************************************************************************************* Admin Panel function  ****************************************************************************************************************************/

void admin() {
        fflush(stdin);
        system("cls");
        title();
        int outercount = 0;
        FILE * fp;
        printf("\n\t\t\tEnter admin password to access  ");
        A1:
                gets(password);

        fp = fopen("password.txt", "r");

        fscanf(fp, "%s", str);

        if (strcmp(str, password) == 0) //This block check whether the password is correct and returns main if tries exceed three times
        {
                printf("\n\t\t\t\tPassword is correct  ");

        } else {
                if (outercount < 3) {
                        printf("\n\t\t\t\tPassword is wrong . Enter Again !");
                        outercount++;
                        goto A1;
                } else {
                        printf("\n\n\t\t\tPassword limit reached ! Press any key to return to main menu !");
                        getch();
                        main();
                }
        }

        int opt;

        system("cls");
        title();
        menuforadmin(); // printf options for admin sub menu
        while (1) {
                scanf("%d", & opt);

                switch (opt) {

                case 0:
                        main();
                        break;
                case 1:
                        editmovies();
                        break;
                case 2:
                        pswrd_change();
                        break;
                case 3:
                        allrecords();
                        break;
                case 4:
                        delete_rec();
                        break;
                case 5:
                        Dlt_all_rec();
                        break;
                case 6:
                        Search_rec();
                        break;
                case 7:
                        edit_record();
                        break;

                }

        }
}

/*************************************************************************************************end of admin function**************************************************************************************/

/************************************************************************************************* Changing password **************************************************************************************/

void pswrd_change() {
        FILE * fp;
        system("cls");
        FILE * newpswrd;
        int count = 0;
        printf("Enter the old password ! ");
        A3:
                fflush(stdin);
        gets(password);

        fp = fopen("password.txt", "w+");

        fgets(str, 15, fp);

        if (strcmp(str, password) == 0) {
                printf("\nPassword is correct  ");

        } else {
                if (count < 3) {
                        printf("\n\nPassword is wrong . Enter Again !");
                        count++;
                        goto A3;
                } else
                        printf("Password limit reached ! Press any key to return to main menu !");
                getch();
                main();
        }
        fflush(stdin);
        char newpassword[15];
        printf("\nEnter the new password for admin panel !  ");
        scanf("%s", & newpassword);
        fputs(newpassword, fp);
        fclose(fp);
        printf("\n\nPassword for admin panel has been changed succesfully");
        getch();
        main();
}
/*************************************************************************************************End of password change function*************************************************************************/

/*************************************************************************************************Deletes a user record**************************************************************************************/
void delete_rec() {
        system("cls");
        title(); // call Title function
        char name[20];
        char moviename[20];
        FILE * ptr, * fp;
        fp = fopen("temp.dat", "w");
        ptr = fopen("CusRecord.dat", "r");
        char ch;
        printf("\n\n\t\t\t++++++++ Delete Customer Record ++++++++\n\n\n");
        control = 0;
        printf("\n\t\tEnter First name to delete the record : ");
        fflush(stdin);
        gets(name);
        printf("\n\t\tEnter Movie name to delete the record : ");
        gets(moviename);

        while ( fscanf(ptr, "%s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, & rec.Gender, & rec.age, rec.Address, rec.Contact_no, & rec.seatnumber, & rec.movieselection, & rec.expenses)!=EOF)

        {

                if (strcmp(rec.First_Name, name) != 0 || strcmp(rec.movieselection, moviename) != 0)
                        fprintf(fp, " %s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, rec.Gender, rec.age, rec.Address, rec.Contact_no, rec.seatnumber, rec.movieselection, rec.expenses);

                else  {
                        printf(" \n\n%s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, rec.Gender, rec.age, rec.Address, rec.Contact_no, rec.seatnumber, rec.movieselection, rec.expenses);
                        control = 1;
                }
        } //while loop ends
        if (control == 0) {
                printf("\n\n\t\t\t Record not found....");
                getch();
                main();
                printf("Do you want to delete more records ? Press 'Y' for yes !");
                ch = getche();
                if (ch == 'y' || ch == 'Y')
                        delete_rec();
        }
        else
        fclose(ptr);
        fclose(fp);
        remove("CusRecord.dat");
        rename("temp.dat", "CusRecord.dat");
        printf("\n\n\t\t\t Record deleted successfully :) ");
        getch();
        main();

}
/*************************************************************************************************End of delete_rec function ************************************************************************************************/

/*************************************************************************************************adding reservation**************************************************************************************/

void addingcustomers() {

        system("cls");
        title(); // call Title function
        //list of variables
        int loop;
        int tempseat;
        int counterforexit = 0;
        char input;
        FILE * ptr; //file pointer
    
        ptr = fopen("CusRecord.dat","a"); //open file in write mode
        printf("\n\n\t\t\t!!!!!!!!!!!!!! Add customer Record !!!!!!!!!!!!!\n");
        W:
                displaymovietobeaired();
        printf("\n");
        fflush(stdin);
        printf("\t\tType movie name for the booking ! or type 'exit' to go  back ");
        scanf("%s", & rec.movieselection);
        if (strcmp(rec.movieselection, movie1name) == 0) {
                rec.expenses = movie1price;
                M:
                        printf("\n\t\t\tSeat  no: ");
                scanf("%d", & tempseat);
                

                if (tempseat > 30 || tempseat < 0) {
                        printf("\n\t\t\tEnter a control seat number between 1-30");
                        goto M;
                } else
                        while (fscanf(ptr, "%s %d", & rec.movieselection, & rec.seatnumber) != EOF) {
                                if (tempseat == rec.seatnumber && (strcmp(rec.movieselection, movie1name) == 0)) {
                                        printf("\n\t\t\tSeat already booked");
                                        goto M;
                                } else
                                        goto A;
                        }

        } else if (strcmp(rec.movieselection, movie2name) == 0) {
                rec.expenses = movie2price;
                R:
                        fflush(stdin);

                printf("\n\t\t\tSeat  no: ");
                scanf("%d", & tempseat);
                

                if (tempseat > 30 || tempseat < 0) {
                        printf("\n\t\t\tEnter a control seat number between 1-30");
                        goto R;
                } else
                        while (fscanf(ptr, "%s %d", rec.movieselection, & rec.seatnumber) != EOF) {
                                if (tempseat == rec.seatnumber && (strcmp(movie2name, rec.movieselection) == 0)) {
                                        printf("\n\t\tSeat already booked");
                                        goto R;
                                } else
                                        goto A;
                        }

        } else if (strcmp(rec.movieselection, movie3name) == 0) {
                rec.expenses = movie3price;
                Q:
                        fflush(stdin);

                printf("\n\t\t\tSeat  no: ");
                scanf("%d", & tempseat);
                
                if (tempseat > 30 || tempseat < 0) {
                        printf("\n\t\t\tEnter a control seat number between 1-30");
                        goto Q;
                } else

                        while (fscanf(ptr, "%s %d", & rec.movieselection, & rec.seatnumber) != EOF) {
                                if (tempseat == rec.seatnumber && (strcmp(movie3name, rec.movieselection) == 0)) {
                                        printf("\n\t\tSeat already booked");
                                        goto Q;
                                } else
                                        goto A;
                        }

        } else if (strcmp(rec.movieselection, movie4name) == 0) {
                rec.expenses = movie4price;
                N:
                        fflush(stdin);
                printf("\n\t\t\tSeat  no: ");
                scanf("%d", & tempseat);
                

                if (tempseat > 30 || tempseat < 0) {
                        printf("\n\t\t\tEnter a control seat number between 1-30");
                        goto N;
                } else
                        while (fscanf(ptr, "%s  %d", & rec.movieselection, & rec.seatnumber) != EOF) {
                                if (tempseat == rec.seatnumber && (strcmp(movie4name, rec.movieselection) == 0)) {
                                        printf("\n\t\tSeat already booked");
                                        goto N;
                                } else
                                        goto A;;
                        }

        } else if (strcmp(rec.movieselection, "exit") == 0) {
                printf("\t\t\t Press any key to return to main menu");
                getch();
                main();

        } else {
                if (counterforexit < 3) {
                        printf("\t\t\tWrong INPUT ! TRY AGAIN ");
                        getch();
                        counterforexit++;
                        goto W;
                } else

                {
                        printf("Press any key to return to main menu");
                        getch();
                        main();
                }
        }

        A:
        rec.seatnumber = tempseat;
        printf("\n\t\t\tFirst Name: ");
        scanf("%s", rec.First_Name);
        if (strlen(rec.First_Name) > 20 || strlen(rec.First_Name) < 2) {
                printf("\n\t Invalid :( \t The max range for first name is 20 and min range is 2 :)");
                goto A;
        }
        /* ********************************************** Last name ************************************************ */
        B:
                fflush(stdin);
        printf("\n\t\t\tLast Name: ");
        scanf("%s", rec.Last_Name);
        if (strlen(rec.Last_Name) > 20 || strlen(rec.Last_Name) < 2) {
                printf("\n\t Invalid :( \t The max range for last name is 20 and min range is 2 :)");
                goto B;
        }
        /* ******************************************* Gender ************************************************************** */
        do {
                E: printf("\n\t\t\tGender[F/M]: ");
                scanf(" %c", & rec.Gender);
                if (rec.Gender == 'M' || rec.Gender == 'F' || rec.Gender == 'm' || rec.Gender == 'f') {
                        temp = 1;
                } else {
                        temp = 0;
                }
                if (temp == 0) {
                        printf("\n\t\t Gender contain Invalid character :(  Enter either F or M :)");
                }
        } while (temp == 0);
        /* ***************************************** Age ********************************************************************** */
        printf("\n\t\t\tAge:");
        scanf(" %d", & rec.age);
        /* **************************************** Address ******************************************************************* */
        C:
                printf("\n\t\t\tAddress: ");
        scanf("%s", rec.Address);
        if (strlen(rec.Address) > 20 || strlen(rec.Address) < 4) {
                printf("\n\t Incontrol :( \t The max range for address is 20 and min range is 4 :)");
                goto C;
        } else
                goto D;

        /* ******************************************* Contact no. ***************************************** */
        do {
                D:
                printf("\n\t\t\tContact no: ");
                scanf("%s", & rec.Contact_no);
                if (strlen(rec.Contact_no) >= 12) {
                        printf("\n\t Sorry :( . Contact no. must contain less than 11 numbers. Enter again :)");
                        goto D;
                } else {
                        for (b = 0; b < strlen(rec.Contact_no); b++) {
                                if (isdigit(rec.Contact_no[b])) {
                                        control = 1;
                                } else {
                                        control = 0;
                                        break;
                                }
                        }
                        if (control == 0) {
                                printf("\n\t\t Contact no. contain Incontrol character :(  Enter again :)");
                                goto D;
                        }
                }
        } while (control == 0);

        printf("\n\t\t\tAdditional expenses in PKR: ");
        scanf("%d", & rec.additionalexp);
        rec.totalexp = rec.additionalexp + rec.expenses;
        fprintf(ptr, " %s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, rec.Gender, rec.age, rec.Address, rec.Contact_no, rec.seatnumber, rec.movieselection, rec.totalexp);
        printf("\n\n\t\t\t.... Information Record Successful ...");
        fclose(ptr); //ptr file is closed
        fflush(stdin);
        printf("\n\n\t\t\tDo you want to add more[Y] / [Any key to end] ? ?? ");
        scanf("%c", & input);
        if (input == 'y' || input == 'Y') {
                addingcustomers();
        } else {
                printf("\n\t\t Thank you :) :)");
                getch();
                main();
        }
}
/*************************************************************************************************end of adding reservation**************************************************************************************/

/************************************************************************************************* Edit names of movies to be aired **************************************************************************************/
void editmovies() {
        int slot;
        system("cls");
        displaymovietobeaired();
        printf("\nEnter the new movie to be aired along with its timing .");
        printf("\nThere can be only 4 slots for movies at a time .");
        printf("\nEnter the slot number !s .");
        scanf("\n%d", & slot);
        switch (slot)

        {

        case 1: {
                FILE * movie1;
                movie1 = fopen("movie1.txt", "w");
                fflush(stdin);
                printf("\nEnter the name of the movie to be aired at %d:00 pm ", 5);
                gets(movie1name);
                fputs(movie1name, movie1);
                fclose(movie1);
                printf("\nPress any key to return to main menu!");
                getch();
                main();
                break;
        }
        case 2: {
                FILE * movie2;
                movie2 = fopen("movie2.txt", "w");
                fflush(stdin);
                printf("\nEnter the name of the movie to be aired at %d:00 pm ", 8);
                gets(movie2name);
                fputs(movie2name, movie2);
                fclose(movie2);
                printf("\nPress any key to return to main menu!");
                getch();
                main();
                break;
        }
        case 3: {
                FILE * movie3;
                movie3 = fopen("movie3.txt", "w");
                fflush(stdin);
                printf("\nEnter the name of the movie to be aired at %d:00 pm ", 10);
                gets(movie3name);
                fputs(movie3name, movie3);
                fclose(movie3);
                printf("\nPress any key to return to main menu!");
                getch();
                main();

                break;
        }
        case 4: {
                FILE * movie4;
                movie4 = fopen("movie4.txt", "w");
                fflush(stdin);
                printf("\nEnter the name of the movie to be aired at %d:00 pm ", 11);
                gets(movie4name);
                fputs(movie4name, movie4);
                fclose(movie4);
                printf("\nPress any key to return to main menu!");
                getch();
                main();
                break;
        }
        }
}
/*************************************************************************************************end of  edit movies function **************************************************************************************/

/************************************************************************************************* Edit names of movies to be aired **************************************************************************************/
void Search_rec() {

        char firstname[20];
        system("cls");
        title(); // call Title function
        FILE * ptr;
        ptr = fopen("CusRecord.dat", "r");
        printf("\n\n\t\t\t+++++++++++ Search customer Record +++++++++++\n\n");
        printf("\n Enter the first name of the customer :");
        scanf("%s", firstname);
        control = 0;
        fflush(stdin);
        printf("\t\t<-------Below are all the record found with this first name ------->");

        while (fscanf(ptr, "%s %s %c %d %s %s %d %s %d/n", rec.First_Name, rec.Last_Name, & rec.Gender, & rec.age, rec.Address, rec.Contact_no, & rec.seatnumber, & rec.movieselection, & rec.expenses) != EOF) {
                if (strcmp(rec.First_Name, firstname) == 0)

                {
                        printf("\n");

                        printf("%s %s\t", rec.First_Name, rec.Last_Name);

                        printf("%c\t", rec.Gender);

                        printf("%d\t", rec.age);

                        printf("%s\t", rec.Address);

                        printf("%s\t", rec.Contact_no);

                        printf("%d\t\t", rec.seatnumber);

                        printf(" %s  %d RS", rec.movieselection, rec.expenses);

                        control = 1;
                }

        }
        if (control == 0) {
                printf("\n\t\t\tNo record found !");
                getch();
                admin();
        } else {
                fclose(ptr);
                getch();
                main();
        }
}

void edit_record() {
        FILE * ptr;
        FILE * fp;
        char ch;
        control = 0;
        char name[20];
        char name2[20];
        system("cls");
        title();
         fflush(stdin);
        fp = fopen("temp.dat", "w");
        ptr = fopen("CusRecord.dat", "r");
        printf("\n\t\t\t   *******Edit Record*******\n");
        printf("Enter the name of buyer : ");
        scanf("%s", name);
        printf("Enter the last name of buyer : ");
        scanf("%s", name2);
        fflush(stdin);
        while (fscanf(ptr, "%s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, & rec.Gender, & rec.age, rec.Address, rec.Contact_no, & rec.seatnumber, & rec.movieselection, & rec.totalexp) != EOF) {
                if (strcmp(rec.First_Name, name) == 0 && strcmp(rec.Last_Name, name2) == 0)

                {
                        printf("\n\n\t\t\tRecord found !!!");
                        control = 1;
                        printf("\n First name : %s\nLast name : %s\nGender : %c\nAge : %d\nAddress : %s\nContact no :%s\nSeat Number : %d\nMovie: %s\nTotal Exp; %d/n", rec.First_Name, rec.Last_Name, rec.Gender, rec.age, rec.Address, rec.Contact_no, rec.seatnumber, rec.movieselection, rec.totalexp);

                        printf("\n\nEnter first name : ");
                        scanf("%s", rec.First_Name);
                        printf("\n\nEnter last name : ");
                        scanf("%s", rec.Last_Name);
                        L:
                        fflush(stdin);
                        printf("\n\nEnter gender: ");
                        scanf("%c", & rec.Gender);
                        if (rec.Gender != 'f' && rec.Gender != 'm' && rec.Gender != 'F' && rec.Gender != 'M') {
                                goto L;
                        }
                        printf("\n\nEnter age: ");
                        scanf("%d", & rec.age);
                        printf("\n\nEnter address : ");
                        scanf("%s", rec.Address);
                        printf("\n\nEnter the contact number : ");
                        scanf("%s", & rec.Contact_no);

                        fprintf(fp, " %s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, rec.Gender, rec.age, rec.Address, rec.Contact_no, rec.seatnumber, rec.movieselection, rec.totalexp);
                } else {
                        fprintf(fp, " %s %s %c %d %s %s %d %s %d", rec.First_Name, rec.Last_Name, rec.Gender, rec.age, rec.Address, rec.Contact_no, rec.seatnumber, rec.movieselection, rec.totalexp);
                }

        }
        if (control == 0) {
                printf("\t\t\tRecord not found!!!");
        }
        fclose(fp);
        fclose(ptr);
        remove("CusRecord.dat");
        rename("temp.dat", "CusRecord.dat");
        printf("\n\nRecord has been updated successuly");
        getch();
        main();
}

