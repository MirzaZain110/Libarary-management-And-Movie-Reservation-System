
/************************************************************************************************* Edit names of movies to be aired **************************************************************************************/
void editmovies()
{
        int slot;
        system("cls");
        displaymovietobeaired();
        printf("\nEnter the new movie to be aired along with its timing .");
        printf("\nThere can be only 4 slots for movies at a time .");
        printf("\nEnter the slot number !s .");
        scanf("\n%d",&slot);
        switch(slot)

        {

             case 1:
               {
                 FILE *movie1;
                 movie1=fopen("movie1.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",5);
                 gets(movie1name);
                 fputs(movie1name,movie1);
                 fclose(movie1);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
                 break;
                }
             case 2:
                { 
                 FILE *movie2;
                 movie2=fopen("movie2.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",8);
                 gets(movie2name);
                 fputs(movie2name,movie2);
                 fclose(movie2);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
                 break;
                }
                 case 3:
               {
                 FILE *movie3;
                 movie3=fopen("movie3.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",10);
               	 gets(movie3name);
                 fputs(movie3name,movie3);
                 fclose(movie3);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
			  	 break;
                }
                 case 4:
               {
                 FILE *movie4;
                 movie4=fopen("movie4.txt","w");
                 fflush(stdin);
                 printf("\nEnter the name of the movie to be aired at %d:00 pm ",11);
                 gets(movie4name);
                 fputs(movie4name,movie4);
                 fclose(movie4);
                 printf("\nPress any key to return to main menu!");
                 getch();
                 main();
                 break;
                }
        }
}
/*************************************************************************************************end of  edit movies function **************************************************************************************/


/*************************************************************************************************Display movie to be aired***********************************************************************************************/
void displaymovietobeaired()
{

        system("cls");
        title();
        FILE *fptr,*fptr2,*fptr3,*fptr4;
        fptr=fopen("movie1.txt","r");
        fptr2=fopen("movie2.txt","r");
        fptr3=fopen("movie3.txt","r");
        fptr4=fopen("movie4.txt","r");
        printf("\n\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        fscanf(fptr, "%s", movie1name);
        printf("\n\n\t\t\t\t\tSlot -1 %s will be aired at 5:00 Pm (%d) RS",movie1name,movie1price);
        fclose(fptr);
        fscanf(fptr2, "%s", movie2name);
        printf("\n\n\t\t\t\t\tSlot -2 %s will be aired at 8:00 Pm (%d) RS",movie2name,movie2price);
        fclose(fptr2);
        fscanf(fptr3, "%s", movie3name);
        printf("\n\n\t\t\t\t\tSlot -3 %s will be aired at 10:00 Pm (%d) RS",movie3name,movie3price);
        fclose(fptr3);
        fscanf(fptr4, "%s", movie4name);
        printf("\n\n\t\t\t\t\tSlot -4 %s will be aired at 11:00 Pm (%d) RS",movie4name,movie4price);
        fclose(fptr4);
        printf("\n\n\t\t+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

}
/************************************************************************************************  End of Displayall_movies function  ************************************************************************************************/
/************************************************************************************************Deletes all the record in the storage **********************************************************************************/
void Dlt_all_rec()
{
    remove("CusRecord.dat");
    printf("\n\t\tAll records deleted successfully");
    getch();
    main();

}
/*************************************************************************************************End of Dlt_all_rec function**********************************************************************************************/

